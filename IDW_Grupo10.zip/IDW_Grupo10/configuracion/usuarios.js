const usuarios = [
    {
        usuario: "admin",
        clave: "1234"
    },
    {
        usuario: "idw",
        clave: "0000"
    }
]